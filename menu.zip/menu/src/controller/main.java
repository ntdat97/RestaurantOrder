package controller;
public class main{
    public static void main(String[] args) {
        login obj = new login();
        obj.setVisible(true);
    }
}